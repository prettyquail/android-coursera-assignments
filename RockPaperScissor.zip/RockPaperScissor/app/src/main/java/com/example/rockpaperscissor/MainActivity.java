package com.example.rockpaperscissor;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
     Button b_rock,b_paper,b_scissor;
     TextView tv_score;
     ImageView iv_computerchoice,iv_humanchoice;
     int HumanScore,ComputerScore=0;
     MediaPlayer rockmusic,papermusic,scissormusic;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rockmusic=MediaPlayer.create(this,R.raw.rock);
        papermusic=MediaPlayer.create(this,R.raw.paper);
        scissormusic=MediaPlayer.create(this,R.raw.scissor);

        b_paper=(Button)findViewById(R.id.b_paper);
        b_scissor=(Button)findViewById(R.id.b_scissor);
        b_rock=(Button)findViewById(R.id.b_rock);
        iv_computerchoice=(ImageView)findViewById(R.id.iv_computerchoice);
        iv_humanchoice=(ImageView)findViewById(R.id.iv_humanchoice);
        tv_score=(TextView)findViewById(R.id.tv_score);

        b_paper.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                papermusic.start();
                iv_humanchoice.setImageResource(R.drawable.paper);
                String message = play_turn("paper");
                Toast.makeText(MainActivity.this,message,Toast.LENGTH_SHORT).show();
                tv_score.setText("Score Human: " + Integer.toString(HumanScore) + "Computer:" + Integer.toString(ComputerScore));
            }
        });

        b_scissor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                scissormusic.start();
                iv_humanchoice.setImageResource(R.drawable.scissors);
                String message = play_turn("scissor");
                Toast.makeText(MainActivity.this,message,Toast.LENGTH_SHORT).show();
                tv_score.setText("Score Human: " + Integer.toString(HumanScore) + "Computer:" + Integer.toString(ComputerScore));
            }
        });

        b_rock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rockmusic.start();
                iv_humanchoice.setImageResource(R.drawable.rock);
                String message = play_turn("rock");
                Toast.makeText(MainActivity.this,message,Toast.LENGTH_SHORT).show();
                tv_score.setText("Score Human: " + Integer.toString(HumanScore) + "Computer:" + Integer.toString(ComputerScore));
            }
        });


    }
    public String play_turn(String player_choice){
        String computer_choice="";
        Random r=new Random();

        //choose 1 2 or 3
        int computer_choice_number=r.nextInt(3)+1;

        if(computer_choice_number==1){
            computer_choice="rock";
        }
        else if(computer_choice_number==2){
            computer_choice="scissor";
        }
        else if(computer_choice_number==3){
            computer_choice="paper";
        }
        if(computer_choice=="rock"){
            iv_computerchoice.setImageResource(R.drawable.rock);
        }
        else if(computer_choice=="paper"){
            iv_computerchoice.setImageResource(R.drawable.paper);
        }
        else if(computer_choice=="scissor"){
            iv_computerchoice.setImageResource(R.drawable.scissors);
        }


        //compare human and computer choice to determine who won
        if(computer_choice==player_choice){
            return "Draw ,Nobody won";
        }
        else if(player_choice=="rock" && computer_choice=="scissor"){
            HumanScore++;
            return "Rock crushes scissors. You win!";
        }
        else if(player_choice=="rock" && computer_choice=="paper"){
            ComputerScore++;
            return "Paper covers rock. Computer wins!";
        }
        else if(player_choice=="scissor" && computer_choice=="rock"){
            ComputerScore++;
            return "Rock crushes scissors. Computer wins!";
        }
        else if(player_choice=="scissor" && computer_choice=="paper"){
            HumanScore++;
            return "Scissor cuts paper. You win!";
        }
        else if(player_choice=="paper" && computer_choice=="rock"){
            HumanScore++;
            return "Paper covers rock. You win!";
        }
        else if(player_choice=="paper" && computer_choice=="scissor"){
            ComputerScore++;
            return "Scissors cuts paper. Computer wins!";
        }
        else return "Not sure";
    }


}